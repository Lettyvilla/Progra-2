package proyecto;

import java.io.IOException;

public class Proyecto {

    public static void main(String[] args) throws IOException {
        Interfaz menu = new Interfaz();
    }
}
